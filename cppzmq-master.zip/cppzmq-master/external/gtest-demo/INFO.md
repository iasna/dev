googletest integration into CMake and travis-ci was based on https://github.com/bast/gtest-demo
